# @hubble-ds/assets

Ilustrações, o ícone e o loader SVG do Hubble.

## Instalação

```bash
npm install @hubble-ds/assets
```

## Como importar

Os arquivos são SVG, então a importação depende do bundler (Vite, Next, etc.):

```tsx
import addBag from "@hubble-ds/assets/ilustrations/add-bag.svg";
import icon from "@hubble-ds/assets/magazord-icon.svg";
import loader from "@hubble-ds/assets/magazord-loader.svg";

<img src={addBag} alt="" />;
```

## Exports

| Subpath | Conteúdo |
|---|---|
| `@hubble-ds/assets/ilustrations/<nome>.svg` | 151 ilustrações (`add-bag`, `basket`, `cart`, `default`, `truck`, ...). A lista completa está em [`ilustrations/`](./ilustrations) |
| `@hubble-ds/assets/magazord-icon.svg` | Ícone da Magazord (usado como favicon) |
| `@hubble-ds/assets/magazord-loader.svg` | Loader da Magazord (o componente `MagazordLoaderIcon` de `@hubble-ds/components` é a versão React) |
| `@hubble-ds/assets/package.json` | Manifesto do pacote |
