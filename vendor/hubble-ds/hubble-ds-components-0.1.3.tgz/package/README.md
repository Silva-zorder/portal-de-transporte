# @hubble-ds/components

Componentes React do Hubble (baseados em Radix/shadcn) e callables imperativos.

## Instalação

```bash
npm install @hubble-ds/components @hubble-ds/styles
```

Peer dependencies: `react` e `react-dom` ^19. Depende de `@hubble-ds/hooks` e `@hubble-ds/utils`.
O CSS vem de [`@hubble-ds/styles`](../styles/README.md) e precisa ser importado.

## Como importar

Cada item tem um subpath, e a raiz reexporta tudo:

```tsx
import { Button } from "@hubble-ds/components/ui/button"; // por subpath (recomendado)
import { Button } from "@hubble-ds/components"; // pela raiz
import { confirmAlert } from "@hubble-ds/components/callables/confirm-alert-callable";
```

Todos os overlays (dialog, alert-dialog, drawer, popover, tooltip, select, combobox,
dropdown-menu, context-menu) aceitam a prop `container` para renderizar em outro nó,
como uma shadow root.

## `ui/*`

Subpath: `@hubble-ds/components/ui/<item>`

| Item | Exports |
|---|---|
| `accordion` | `Accordion`, `AccordionContent`, `AccordionItem`, `AccordionTrigger` |
| `alert-dialog` | `AlertDialog`, `AlertDialogAction`, `AlertDialogCancel`, `AlertDialogContent`, `AlertDialogDescription`, `AlertDialogFooter`, `AlertDialogHeader`, `AlertDialogOverlay`, `AlertDialogPortal`, `AlertDialogTitle`, `AlertDialogTrigger` |
| `aspect-ratio` | `AspectRatio` |
| `avatar` | `Avatar`, `AvatarBadge`, `AvatarDisplay`, `AvatarFallback`, `AvatarGroup`, `AvatarImage` |
| `badge` | `Badge`, `badgeVariants` |
| `breadcrumb` | `Breadcrumb`, `BreadcrumbEllipsis`, `BreadcrumbItem`, `BreadcrumbLink`, `BreadcrumbList`, `BreadcrumbPage`, `BreadcrumbSeparator` |
| `button` | `Button`, `buttonVariants` |
| `button-group` | `ButtonGroup`, `ButtonGroupSeparator`, `ButtonGroupText`, `buttonGroupVariants` |
| `calendar` | `Calendar`, `CalendarDayButton` |
| `card` | `Card`, `CardAction`, `CardContent`, `CardDescription`, `CardFooter`, `CardHeader`, `CardTitle` |
| `carousel` | `Carousel`, `CarouselApi` (tipo), `CarouselContent`, `CarouselContext`, `CarouselItem`, `CarouselNext`, `CarouselPrevious` |
| `chart` | `ChartContainer`, `ChartLegend`, `ChartLegendContent`, `ChartTooltip`, `ChartTooltipContent`, `getPayloadConfigFromPayload` |
| `checkbox` | `Checkbox` |
| `collapsible` | `Collapsible`, `CollapsibleContent`, `CollapsibleTrigger` |
| `combobox` | `Combobox`, `ComboboxAnchor`, `ComboboxBadgeItem`, `ComboboxBadgeList`, `ComboboxBadgeOverflow`, `ComboboxBadgeOverflowContent`, `ComboboxBadgeOverflowTrigger`, `ComboboxCancel`, `ComboboxContent`, `ComboboxEmpty`, `ComboboxGroup`, `ComboboxGroupLabel`, `ComboboxInput`, `ComboboxItem`, `ComboboxItemDescription`, `ComboboxItemIndicator`, `ComboboxItemText`, `ComboboxLabel`, `ComboboxLoading`, `ComboboxSeparator`, `ComboboxTree`, `ComboboxTreeBranch`, `ComboboxTreeBranchContent`, `ComboboxTreeBranchEmpty`, `ComboboxTreeBranchLoading`, `ComboboxTreeBranchTrigger`, `ComboboxTreeCaption`, `ComboboxTreeCheckbox`, `ComboboxTreeContent`, `ComboboxTreeEmpty`, `ComboboxTreeIndent`, `ComboboxTreeItem`, `ComboboxTreeNode`, `ComboboxTrigger`, `normalizeComboboxSearch`, `useCombobox`, `useComboboxBadgeOverflow`, `useComboboxTree`, `useComboboxTreeNode` |
| `command` | `Command`, `CommandDialog`, `CommandEmpty`, `CommandGroup`, `CommandInput`, `CommandItem`, `CommandList`, `CommandSeparator`, `CommandShortcut` |
| `context-menu` | `ContextMenu`, `ContextMenuCheckboxItem`, `ContextMenuContent`, `ContextMenuGroup`, `ContextMenuItem`, `ContextMenuLabel`, `ContextMenuPortal`, `ContextMenuRadioGroup`, `ContextMenuRadioItem`, `ContextMenuSeparator`, `ContextMenuShortcut`, `ContextMenuSub`, `ContextMenuSubContent`, `ContextMenuSubTrigger`, `ContextMenuTrigger` |
| `counter` | `Counter`, `CounterInputControls`, `CounterInputDecrement`, `CounterInputField`, `CounterInputIncrement` |
| `data-table` | `DataTable`, `DataTableCell`, `DataTableColumn`, `DataTableColumnActions`, `DataTableColumnSortingIndicator`, `DataTableFooter`, `DataTableGrid`, `DataTableGridBody`, `DataTableGridEmpty`, `DataTableGridFooter`, `DataTableGridHeader`, `DataTableGridLoading`, `DataTableGridRecords`, `DataTableGridScrollArea`, `DataTableHeader`, `DataTablePagination`, `PAGINATION_PAGE_SIZES`, `createDataTableColumnHelper`, `createDataTableCoreOptions`, `createDataTableRowSelectionColumnDef`, `useDataTable` |
| `dialog` | `Dialog`, `DialogClose`, `DialogCloseButton`, `DialogContent`, `DialogDescription`, `DialogFooter`, `DialogHeader`, `DialogOverlay`, `DialogPortal`, `DialogTitle`, `DialogTrigger` |
| `drawer` | `Drawer`, `DrawerClose`, `DrawerContent`, `DrawerFooter`, `DrawerHeader`, `DrawerOverlay`, `DrawerPortal`, `DrawerTitle`, `DrawerTrigger` |
| `dropdown-menu` | `DropdownMenu`, `DropdownMenuCheckboxItem`, `DropdownMenuContent`, `DropdownMenuGroup`, `DropdownMenuItem`, `DropdownMenuLabel`, `DropdownMenuPortal`, `DropdownMenuRadioGroup`, `DropdownMenuRadioItem`, `DropdownMenuSeparator`, `DropdownMenuShortcut`, `DropdownMenuSub`, `DropdownMenuSubContent`, `DropdownMenuSubTrigger`, `DropdownMenuSwitchItem`, `DropdownMenuToggleItem`, `DropdownMenuTrigger` |
| `empty` | `Empty`, `EmptyContent`, `EmptyDescription`, `EmptyHeader`, `EmptyMedia`, `EmptyTitle` |
| `field` | `Field`, `FieldContent`, `FieldDescription`, `FieldError`, `FieldGroup`, `FieldLabel`, `FieldLegend`, `FieldSeparator`, `FieldSet`, `FieldTitle` |
| `file-upload` | `FileUpload`, `FileUploadClear`, `FileUploadDropzone`, `FileUploadDropzoneDescription`, `FileUploadDropzoneMedia`, `FileUploadDropzoneTitle`, `FileUploadItem`, `FileUploadItemDelete`, `FileUploadItemMetadata`, `FileUploadItemPreview`, `FileUploadItemProgress`, `FileUploadList`, `FileUploadTrigger`, `useFileUpload` |
| `hint` | `Hint` |
| `icon-button` | `IconButton`, `iconButtonVariants` |
| `input` | `Input`, `inputVariants` |
| `input-group` | `InputGroup`, `InputGroupAddon`, `InputGroupButton`, `InputGroupIconButton`, `InputGroupInput`, `InputGroupText`, `InputGroupTextarea` |
| `input-otp` | `InputOTP`, `InputOTPGroup`, `InputOTPSeparator`, `InputOTPSlot` |
| `label` | `Label` |
| `loading` | `Loading`, `LoadingIndicator`, `LoadingMessage` |
| `magazord-loader-icon` | `MagazordLoaderIcon` |
| `pagination` | `Pagination`, `PaginationContent`, `PaginationEllipsis`, `PaginationIndicator`, `PaginationItem`, `PaginationNextButton`, `PaginationPreviousButton` |
| `popover` | `Popover`, `PopoverAnchor`, `PopoverContent`, `PopoverDescription`, `PopoverHeader`, `PopoverTitle`, `PopoverTrigger` |
| `progress` | `Progress` |
| `radio-group` | `RadioGroup`, `RadioGroupItem` |
| `scroll-area` | `ScrollArea`, `ScrollBar` |
| `select` | `Select`, `SelectContent`, `SelectGroup`, `SelectItem`, `SelectLabel`, `SelectScrollDownButton`, `SelectScrollUpButton`, `SelectSeparator`, `SelectTrigger`, `SelectValue` |
| `separator` | `Separator` |
| `sidebar` | `Sidebar`, `SidebarContent`, `SidebarFooter`, `SidebarGroup`, `SidebarGroupAction`, `SidebarGroupContent`, `SidebarGroupLabel`, `SidebarHeader`, `SidebarInput`, `SidebarInset`, `SidebarMenu`, `SidebarMenuAction`, `SidebarMenuBadge`, `SidebarMenuButton`, `SidebarMenuItem`, `SidebarMenuSkeleton`, `SidebarMenuSub`, `SidebarMenuSubButton`, `SidebarMenuSubItem`, `SidebarProvider`, `SidebarRail`, `SidebarSeparator`, `SidebarTrigger`, `useSidebar` |
| `skeleton` | `Skeleton` |
| `slider` | `Slider` |
| `switch` | `Switch` |
| `table` | `Table`, `TableBody`, `TableCaption`, `TableCell`, `TableFooter`, `TableHead`, `TableHeader`, `TableRow`, `TableScrollArea` |
| `tabs` | `Tabs`, `TabsContent`, `TabsList`, `TabsTrigger` |
| `textarea` | `Textarea` |
| `toast` | `toast`, `ToastProvider` |
| `toggle` | `Toggle`, `toggleVariants` |
| `toggle-group` | `ToggleGroup`, `ToggleGroupItem` |
| `tooltip` | `Tooltip`, `TooltipContent`, `TooltipProvider`, `TooltipTrigger` |

## `callables/*`

Subpath: `@hubble-ds/components/callables/<item>`. Diálogos imperativos baseados em
[`react-call`](https://react-call.desko.dev/).

| Item | Exports |
|---|---|
| `confirm-alert-callable` | `ConfirmAlertCallable`, `confirmAlert` |

Monte `<ConfirmAlertCallable />` uma única vez na árvore da app e chame
`await confirmAlert({ title, description })`, que resolve `true` (ação) ou `false` (cancelar).

## Observações

- `SidebarMenuButton` com `tooltip` exige um `TooltipProvider` acima.
- `CommandDialog` precisa de um `<Command>` dentro do conteúdo.
- Drawer e Toast não têm garantia em shadow DOM (as libs injetam CSS em `document.head`).
- `DataTablePagination` aceita `pageSizes` com os registros por página oferecidos no select,
  na ordem informada. Sem a prop, usa `PAGINATION_PAGE_SIZES` (10, 20, 25, 30, 40, 50). Inclua na
  lista o `pageSize` inicial da tabela, senão o select fica sem valor. Para estender a lista padrão,
  espalhe a constante e acrescente os tamanhos novos, em vez de repetir os valores:
  `<DataTablePagination pageSizes={[...PAGINATION_PAGE_SIZES, 100, 250, 500]} />`. Escreva a lista
  inteira só quando precisar de tamanhos que a padrão não tem no meio dela.
- `DataTableColumnActions` aceita `additionalActions` com ações adicionais para o menu da coluna. Elas
  entram no fim, depois de "Colunas", e as ações padrão continuam. O componente renderiza a prop como
  recebe: a composição (separador, grupos, submenus) fica com quem usa. Passe peças do `dropdown-menu`:
  `<DataTableColumnActions column={column} additionalActions={<><DropdownMenuSeparator /><DropdownMenuItem>Exportar</DropdownMenuItem></>} />`.
  Para substituir o menu inteiro, use `children`.
