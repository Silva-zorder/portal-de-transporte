# @hubble-ds/hooks

Hooks React reutilizáveis do Hubble.

## Instalação

```bash
npm install @hubble-ds/hooks
```

Peer dependency: `react` ^19.

## Como importar

```ts
import { useIsMobile } from "@hubble-ds/hooks/use-is-mobile"; // por subpath (recomendado)
import { useIsMobile } from "@hubble-ds/hooks"; // pela raiz
```

## Exports

| Subpath | Exports |
|---|---|
| `@hubble-ds/hooks/use-as-ref` | `useAsRef` |
| `@hubble-ds/hooks/use-boolean` | `useBoolean` |
| `@hubble-ds/hooks/use-breadcrumbs` | `useBreadcrumbs` e os tipos `BreadcrumbItem`, `UseBreadcrumbsOptions`, `UseBreadcrumbsResult` |
| `@hubble-ds/hooks/use-breakpoint` | `useBreakpoint` |
| `@hubble-ds/hooks/use-callback-ref` | `useCallbackRef` |
| `@hubble-ds/hooks/use-controlled-state` | `useControlledState` |
| `@hubble-ds/hooks/use-copy-to-clipboard` | `useCopyToClipboard` |
| `@hubble-ds/hooks/use-debounce` | `useDebounce` |
| `@hubble-ds/hooks/use-device-detect` | `useDeviceDetect` |
| `@hubble-ds/hooks/use-error-boundary` | `useErrorBoundary` |
| `@hubble-ds/hooks/use-fullscreen` | `useFullscreen` |
| `@hubble-ds/hooks/use-infinite-scroll` | `useInfiniteScroll` |
| `@hubble-ds/hooks/use-is-mobile` | `useIsMobile` |
| `@hubble-ds/hooks/use-isomorphic-layout-effect` | `useIsomorphicLayoutEffect` |
| `@hubble-ds/hooks/use-keyed-array` | `useKeyedArray` |
| `@hubble-ds/hooks/use-lazy-ref` | `useLazyRef` |
| `@hubble-ds/hooks/use-local-storage` | `useLocalStorage` |
| `@hubble-ds/hooks/use-map` | `useMap` |
| `@hubble-ds/hooks/use-mount` | `useMount` |
| `@hubble-ds/hooks/use-multi-step-form` | `useMultiStepForm` |
| `@hubble-ds/hooks/use-payload-diff-guard` | `usePayloadDiffGuard` e os tipos `PayloadDiffChangeType`, `PayloadDiffEntry`, `PayloadPath`, `UsePayloadDiffGuardOptions`, `UsePayloadDiffGuardResult` |
| `@hubble-ds/hooks/use-script` | `useScript` |
| `@hubble-ds/hooks/use-set` | `useSet` |
| `@hubble-ds/hooks/use-store-with-selector` | `useStoreWithSelector` e o tipo `StoreSelector` |
| `@hubble-ds/hooks/use-throttle` | `useThrottle` |
| `@hubble-ds/hooks/use-uncontrolled-state` | `useUncontrolledState` |
| `@hubble-ds/hooks/use-unmount` | `useUnmount` |

## Fontes de hooks

Hooks genéricos que não temos vêm de dois catálogos. Nenhum é dependência do Hubble: copiamos o código, adaptamos e redistribuímos pelo `@hubble-ds/hooks`.

| Fonte | Licença | Onde está o código | Aviso no cabeçalho do arquivo |
|---|---|---|---|
| [useKit](https://usekit.kiron.dev) (150+ hooks) | MIT | [`registry/hooks/<nome>.ts`](https://github.com/kiron0/usekit) (ou `npx uselab@latest add <nome>` num diretório temporário) | **Obrigatório**: `Adaptado de useKit (https://usekit.kiron.dev), MIT, © 2025 Toufiq Hasan Kiron.` |
| [ReactUse](https://reactuse.com) (110+ hooks, pacote `@reactuses/core`) | Unlicense (domínio público) | [`packages/core/src/<useNome>/index.ts`](https://github.com/childrentime/reactuse) | Não exigido; registre a origem mesmo assim: `Adaptado de ReactUse (https://reactuse.com).` |

Para trazer um hook novo:

1. Confirme que o hook não existe na tabela acima nem em outra fonte já usada, e que algum consumidor precisa dele. Catálogos têm hooks de jogo, Bluetooth e afins que não vamos redistribuir.
2. **Leia o código** da fonte: é a única garantia de qualidade. Para o ReactUse, copie o código, **não** instale `@reactuses/core` (uma dependência a mais, com os mesmos hooks que já queremos controlar).
3. Copie para `packages/hooks/src/<nome>.ts`, adaptando ao padrão do Hubble (kebab-case no arquivo, exports nomeados no fim, efeitos que limpam tudo que registram, seguro para SSR) e exporte no `index.ts`. Hooks do ReactUse costumam depender de utilitários internos dele (`useLatest`, `isBrowser`...): troque pelos equivalentes do Hubble (`useAsRef`, `useIsomorphicLayoutEffect`...) em vez de copiar a cadeia.
4. Escreva o teste em `packages/hooks/tests/` (jsdom) e registre o hook na tabela de exports acima.

Escolhendo entre as duas fontes para o mesmo hook, prefira a implementação menor e com menos dependências internas.
