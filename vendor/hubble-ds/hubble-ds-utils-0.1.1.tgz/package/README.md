# @hubble-ds/utils

Funções utilitárias, schemas zod, enums e a fábrica de microfrontend em shadow DOM do Hubble.

## Instalação

```bash
npm install @hubble-ds/utils
```

Peer dependencies opcionais: `react` e `react-dom` (só para `entrypoint-shadow-dom`).

## Como importar

Cada item tem um subpath com o nome do arquivo, e a raiz reexporta tudo:

```ts
import { isValidCpf, maskCpf } from "@hubble-ds/utils/cpf"; // por subpath (recomendado)
import { isValidCpf, maskCpf } from "@hubble-ds/utils"; // pela raiz
import { EnumEnvironment } from "@hubble-ds/utils/enum";
```

## Exports

| Subpath | Exports |
|---|---|
| `@hubble-ds/utils/cep` | `cepSchema`, `hasSameCep`, `isInvalidCep`, `isValidCep`, `maskCep`, `unmaskCep` |
| `@hubble-ds/utils/cnpj` | `cnpjSchema`, `isInvalidCnpj`, `isValidCnpj`, `maskCnpj`, `unmaskCnpj` |
| `@hubble-ds/utils/cpf` | `cpfSchema`, `isInvalidCpf`, `isValidCpf`, `maskCpf`, `unmaskCpf` |
| `@hubble-ds/utils/cpf-cnpj` | `cpfCnpjSchema`, `isInvalidCpfCnpj`, `isValidCpfCnpj`, `maskCpfCnpj`, `unmaskCpfCnpj` |
| `@hubble-ds/utils/date` | `isValidDate`, `maskDate`, `unmaskDate` e as constantes `DATE_PATTERN_BR`, `DATE_PATTERN_BR_DATETIME`, `DATE_PATTERN_BR_DATETIME_SEC`, `DATE_PATTERN_FULL_BR`, `DATE_PATTERN_ISO`, `DATE_PATTERN_ISO_DATETIME`, `DATE_PATTERN_MONTH_YEAR`, `DATE_PATTERN_MONTH_YEAR_BR`, `DATE_PATTERN_RELATIVE`, `DATE_PATTERN_SUFIXED_RELATIVE`, `DATE_PATTERN_TIME`, `DATE_PATTERN_TIME_SEC`, `DATE_PATTERN_US` |
| `@hubble-ds/utils/email` | `emailSchema`, `INVALID_EMAIL_DOMAINS`, `isInvalidEmail`, `isValidEmail`, `normalizeEmail`, `VALID_EMAIL_HOSTINGS` |
| `@hubble-ds/utils/entrypoint-shadow-dom` | `withShadowDom`, `useEntrypointShadowDom` e os tipos `EntrypointBridge`, `EntrypointEventPayloads`, `EntrypointEventSchemas`, `EntrypointOptions`, `EntrypointParsedOptions` |
| `@hubble-ds/utils/enum` | `EnumEnvironment`, `EnumEnvironmentCaption`, `EnumEnvironmentOptions` e os tipos `EnumEnvironmentKey`, `EnumEnvironmentValue` |
| `@hubble-ds/utils/file` | `maskBytes` |
| `@hubble-ds/utils/mask` | `applyMaskGroups`, `onlyDigits` e o tipo `MaskGroup` (base das máscaras progressivas) |
| `@hubble-ds/utils/monetary` | `maskMonetary`, `unmaskMonetary`, `unmaskMonetaryInput`, `MAX_MONETARY_VALUE` |
| `@hubble-ds/utils/number` | `absolute`, `clamp`, `truncate` |
| `@hubble-ds/utils/percentage` | `maskPercentage`, `unmaskPercentage`, `unmaskPercentageInput` |
| `@hubble-ds/utils/phone` | `isInvalidPhone`, `isValidPhone`, `maskPhone`, `phoneSchema`, `unmaskPhone` |
| `@hubble-ds/utils/string` | `extractNameInitials` |

### Convenções

- `mask*` formata o valor e **serve para campo de digitação**: aceita valor parcial (`maskCpf("5299")` → `"529.9"`), descarta o que não cabe e nunca deixa separador órfão no fim, então digitar e apagar caracteres produz o mesmo resultado. Vale para `maskCep`, `maskCpf`, `maskCnpj`, `maskCpfCnpj` e `maskPhone`. Não validam: use `isValid*`/`*Schema` para isso.
- `unmask*` devolve só os dígitos/valor cru, também de valor parcial (`unmaskCpf("529.9")` → `"5299"`).
- `maskMonetary` e `maskPercentage` tratam `NaN`/infinito como zero (campo ainda sem valor). Para ler o campo de digitação, use `unmaskMonetaryInput` e `unmaskPercentageInput`, que leem os dígitos como centavos/centésimos (`"R$ 1,50"` → `1.5`); o `unmask*` decimal não serve, porque a máscara sempre emite duas casas.
- `isValid*` / `isInvalid*` validam o valor; `*Schema` é o schema zod equivalente, com mensagens em pt-BR.

### Enums

```ts
import {
  EnumEnvironment,
  EnumEnvironmentOptions,
  type EnumEnvironmentValue,
} from "@hubble-ds/utils/enum";

EnumEnvironment.PRODUCTION; // "production"
EnumEnvironmentOptions;
// [
//   { value: "development", caption: "Desenvolvimento" },
//   { value: "production", caption: "Produção" },
//   { value: "test", caption: "Teste" },
// ]
```

### Shadow DOM

`withShadowDom` monta uma app React em uma shadow root. O guia completo está em
[`docs/shadow-dom.md`](../../docs/shadow-dom.md).
