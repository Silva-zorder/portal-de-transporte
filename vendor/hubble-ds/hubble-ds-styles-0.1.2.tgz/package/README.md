# @hubble-ds/styles

CSS do Hubble: tokens do tema, fontes e o CSS gerado dos componentes. Só CSS, sem runtime.

## Instalação

```bash
npm install @hubble-ds/styles
```

Peer dependency: `tailwindcss` ^4.

## Como importar

Na ordem abaixo, no CSS de entrada da app:

```css
@import "tailwindcss";
@import "@hubble-ds/styles/theme.css";
@import "@hubble-ds/styles/components.css";
@import "@hubble-ds/styles/fonts.css"; /* opcional */
```

## Arquivos

| Subpath | Conteúdo |
|---|---|
| `@hubble-ds/styles` / `@hubble-ds/styles/theme.css` | Tokens (cores, espaçamento, raio, sombra, tipografia `typo-*`, grid `grid-cols-auto-*`), claro e escuro. Importa `tw-animate-css` e `shadcn-tailwind.css` |
| `@hubble-ds/styles/components.css` | CSS de todos os componentes, em `@layer utilities` |
| `@hubble-ds/styles/fonts.css` | Roboto Variable e Roboto Mono Variable (`@fontsource-variable`). Opcional; em Next, defina `--font-sans` com `next/font` |
| `@hubble-ds/styles/shadcn-tailwind.css` | Utilitários base herdados do shadcn (importado pelo `theme.css`) |

`components.css` é gerado no build (`npm run build:styles`) e não
ficam versionados. O Tailwind não escaneia `node_modules`, por isso o consumidor não
precisa configurar `@source`.
